

<?php $__env->startSection('main_content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body>


<div id="page-wrapper" class="container">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        
                    </div>
                </div>
             
              
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                           
                                            <th> Name</th>
                                            <th>email</th>

                                           
                                            <th>gender</th>
                                            <th>languages</th>
											<th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                       
                                                 <tr>
                                            <td><img src="" width="50px"></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                            <td></td>
                                            <td></td>
                                            <td></td>

											<td>

												<a href=""class="btn btn-danger me-1">Delete</a>
												<a href="" class="btn btn-primary me-1">Edit</a>
											</td>
                                        </tr>
                                    
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                  
                </div>
          
            </div>
      
               
            </div>
        </div>
     
    </div>
   

</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Photo Gallery\resources\views/view.blade.php ENDPATH**/ ?>