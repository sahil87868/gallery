@include('layout.header')
@yield('main_content')
@include('layout.footer')